import logging
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
import numpy as np
from transformers import pipeline
from PIL import Image
import io

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE"], 
    allow_headers=["*"], 
)
pipe = pipeline(task="depth-estimation", model="LiheYoung/depth-anything-small-hf")

# print error message
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


handler = logging.FileHandler("app.log")
handler.setLevel(logging.INFO)


formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)


logger.addHandler(handler)

@app.post("/upload")
async def create_upload_file(file: UploadFile = File(...)):
    contents = await file.read()
    image = Image.open(io.BytesIO(contents))
    
    try:
        logger.info("Received image for processing")
        
        depth = pipe(image)["depth"]
        depth_normalized = (depth - np.min(depth)) / (np.max(depth) - np.min(depth))
        depth_image = (depth_normalized * 255).astype(np.uint8)
        img = Image.fromarray(depth_image, 'L')
        
        buf = io.BytesIO()
        img.save(buf, format='PNG')
        buf.seek(0)
        
        logger.info("Processed image successfully")
        
        response = StreamingResponse(buf, media_type="image/png")
        return response
    except Exception as e:
        logger.error(f"Error processing image: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")
    finally:
        logger.info("Response sent successfully")

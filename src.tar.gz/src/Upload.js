import React, { Component } from 'react';

class Upload extends Component {
  state = {
    isUploading: false,
    result: null,
    selectedFile: null
  };

  uploadFile = () => {
    const { selectedFile } = this.state;
    const formData = new FormData();
    formData.append('file', selectedFile);

    this.setState({ isUploading: true });

    // upload file
    fetch('http://127.0.0.1:8000/upload', {
      method: 'POST',
      body: formData,
      timeout: 60000 // set timeout is 60s
    })
      .then(response => {
        if (!response.ok) {
          throw new Error('Failed to upload image');
        }
        return response.blob();
      })
      .then(blob => {
        const imageUrl = URL.createObjectURL(blob);
        console.log('Received image URL:', imageUrl); 
        this.setState({ isUploading: false, result: imageUrl });
      })
      .catch(error => {
        console.error('Error:', error);
        this.setState({ isUploading: false });
      });
  };

  handleFileChange = (event) => {
    const file = event.target.files[0];
    this.setState({ selectedFile: file });
  };

  render() {
    const { isUploading, result } = this.state;

    return (
      <div>
        <h2>Choose Pic</h2>
        <input type="file" id="file-input" onChange={this.handleFileChange} />
        <button type="button" onClick={this.uploadFile} disabled={isUploading || !this.state.selectedFile}>Upload</button>
        {isUploading && <p>Uploading...</p >}
        {result && < img src={result} alt="Result" />}
      </div>
    );
  }
}

export default Upload;
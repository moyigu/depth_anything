import Upload from './Upload.js'
import './App.css';

function App() {
  return (
    <div>
      <h1>Welcome Depth Anything!</h1>
      <Upload />
    </div>
  );
}
export default App;
